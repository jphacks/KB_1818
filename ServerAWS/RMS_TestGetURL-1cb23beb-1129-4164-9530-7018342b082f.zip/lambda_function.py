import requests
import json
from bs4 import BeautifulSoup
import os
from urllib import request as req
from urllib import error
from urllib import parse
import bs4
import re

def lambda_handler(event, context):
    appid = 'dj00aiZpPU1CMGdvVU1lakJnYSZzPWNvbnN1bWVyc2VjcmV0Jng9NmE-'

    jan = event['barcode'] # タフグミ

    baseURL = 'http://www.janken.jp/goods/jk_catalog_syosai.php?jan='+jan
    requestURL = baseURL
    # requestURL = baseURL + '?' + 'appid=' + appid + '&' + 'jan=' + jan
    response = requests.get(requestURL)
    response.encoding = response.apparent_encoding
    print(response)
    soup = BeautifulSoup(response.text, 'lxml')
    tables = soup.findAll('div', class_='jktitletxt1')
    print(tables)

    match = re.search(r'<h1>(.+)</h1>', str(tables))
    if match:
        # print(match.group(0))  # 検索パターン全体に一致する文字列
        print(match.group(1))  # 検索パターン中の括弧で囲まれた部分に一致する文字列
    # 商品名
    keyword = match.group(1)

    urlKeyword = parse.quote(keyword)
    url = 'https://www.google.com/search?hl=jp&num=5&q=' + urlKeyword + '&btnG=Google+Search&tbs=0&safe=off&tbm=isch'

    headers = {"User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:47.0) Gecko/20100101 Firefox/47.0",}
    request = req.Request(url=url, headers=headers)
    page = req.urlopen(request)

    html = page.read().decode('utf-8')
    html = bs4.BeautifulSoup(html, "html.parser")
    elems = html.select('.rg_meta.notranslate')
    counter = 0

    for ele in elems:
        ele = ele.contents[0].replace('"','').split(',')
        # print(ele)
        eledict = dict()
        for e in ele:
            num = e.find(':')
            eledict[e[0:num]] = e[num+1:]
        imageURL = eledict['ou']

        pal = '.jpg'
        if '.jpg' in imageURL:
            pal = '.jpg'
        elif '.JPG' in imageURL:
            pal = '.jpg'
        elif '.png' in imageURL:
            pal = '.png'
        elif '.gif' in imageURL:
            pal = '.gif'
        elif '.jpeg' in imageURL:
            pal = '.jpeg'
        else:
            pal = '.jpg'

        try:
            counter += 1
            break
        except UnicodeEncodeError:
            continue
        except error.HTTPError:
            continue
        except error.URLError:
            continue
    # 画像のURL
    res = {
        "FoodName":keyword,
        "imageURL":imageURL
    }
    return res
